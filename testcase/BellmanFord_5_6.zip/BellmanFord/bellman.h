/*
* Author: Võ Tiến
* Date: 26.04.2023
*/
#ifndef _H_BELLMAN_FORD_ALGORITHM_H_
#define _H_BELLMAN_FORD_ALGORITHM_H_

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <set>

using namespace std;
inline ofstream OUTPUT;

/*
* Mô tả : Bellman-Ford calculation: Write function BF() to calculate 1 step of Bellman-Ford on an input graph.
* input
    ^ G : đồ thị đang ở dạng ma trận
    ^ numberOfVertices : số lượng đỉnh của ma trận
    ^ startVertex : điểm bắt đầu
    ^ Label : mảng khoảng cách min hiện tại từ điểm đầu đến điểm hiện đó
    ^ Prev : để đạt được khoảng sách min ở label trên lưu điểm trước nó (dạng A,B,C,D ...)
*/
void BF( int** G, int numberOfVertices, char startVertex, int* Label, int* Prev);

/*

*/
string BF_Path( int** G, int numberOfVertices, char startVertex, char goalVertex);

////////////////////////////////////////////////
/// END OF STUDENT'S ANSWER
////////////////////////////////////////////////
#endif /* _H_BELLMAN_FORD_ALGORITHM_H_ */