#include "bellman.h"

void BF(int **G, int numberOfVertices, char startVertex, int *Label, int *Prev)
{
}

string BF_Path(int **G, int numberOfVertices, char startVertex, char goalVertex)
{
    return "";
}