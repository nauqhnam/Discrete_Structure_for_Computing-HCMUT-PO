#include "tsp.h"

/*
 * Author: Võ Tiến
 * Date: 07.08=5.2023
 * FB: https://www.facebook.com/profile.php?id=700056605580171
 * FB nhóm: https://www.facebook.com/groups/211867931379013
 */
/*
* cách dùng hàm main.cpp
* b1: mở folder BTL1 lên vscode
* b2: mở Terminal trên thanh công cụ mở new Terminal
* b3: chạy lệnh g++ -o main main.cpp tsp.cpp nếu không gì hiện ra thì không bị lỗi code
* b4: chạy ./main KEYWORDS
* b5: nếu hiện Success: test 1 to 1000 thì đã đúng hết

! KEYWORDS có thể là
* ./main 2 này chạy phần input2
* ./main 1 5 này sẽ chạy phần input1 -> input5
* output là output của bạn, expect là đáp án, input là dữ liệu đầu vào
*/

#define folder_input "testCase/input/input"
#define folder_output "testCase/output/output"
#define folder_expect "testCase/expect/expect"

bool isNumber(string str);
void comparefile(int start, int end);

int pathDistance(string str, int **G)
{
    int distance = 0;
    if (str.length() == 1)
        return 0;
    for (int i = 0; i < str.length() - 2; i++)
    {
        if (str[i] >= 'A' && str[i] <= 'Z')
            distance += G[str[i] - 'A'][str[i + 2] - 'A'];
    }
    return distance;
}

void run_bellman(string fileName)
{
    ifstream file(folder_input + fileName + ".txt");
    if (!file.is_open())
    {
        cout << "Error: " << fileName << endl;
        return;
    }
    string s;
    file >> s;
    file >> s;
    file >> s;
    int v = stoi(s);
    OUTPUT << "v = " << v << endl;

    int **G = new int *[v];
    for (int i = 0; i < v; i++)
    {
        G[i] = new int[v];
        for (int j = 0; j < v; j++)
        {
            file >> G[i][j];
            OUTPUT << G[i][j] << " ";
        }
        OUTPUT << "\n";
    }

    char startV = 'A';
    string result = Traveling(G, v, startV);
    // OUTPUT << "Traveling : " << result << endl;
    if (result == "No path exists")
    {
        OUTPUT << "Distance : " << -1 << endl;
    }
    else
        OUTPUT << "Distance : " << pathDistance(result, G) << endl;
    for (int i = 0; i < v; i++)
        delete G[i];
    delete[] G;

    file.close();
}

//* ./main
//* ./main i j (với i với j là số từ test i -> j)
//* ./main i (i là test cần test)
int main(int argc, char *argv[])
{
    cout << "Start program assignments DS" << endl;

    int START = 0, END = 0;
    int fullTask = 1000;
    //* check all test cases

    if (argc == 1)
    {
        cout << "checking test : ";
        START = 1;
        END = 1000;
        for (int i = START; i <= END; i++)
        {
            cout << i << " ";
            OUTPUT.open(folder_output + to_string(i) + ".txt");
            run_bellman(to_string(i));

            OUTPUT.close();
        }
    }

    else if (argc == 2)
    {

        string stringTask = argv[1];
        if (isNumber(stringTask))
        {
            cout << "checking test : " << argv[1];
            START = stoi(stringTask);
            END = stoi(stringTask);
            OUTPUT.open(folder_output + stringTask + ".txt");
            run_bellman(stringTask);
            OUTPUT.close();
        }
        else if (stringTask == "me")
        {
            cout << "checking test : ";
            for (int i = 1; i <= 1000; i++)
            {
                cout << i << " ";
                OUTPUT.open(folder_expect + to_string(i) + ".txt");
                run_bellman(to_string(i));
                OUTPUT.close();
            }
        }
        else if (stringTask.substr(0, 4) != "task" || stringTask[4] <= '0' || stringTask[4] > '3')
        {
            cout << "Please re-enter the correct command" << endl;
            cout << "./main task1\n./main task2\n./main task3\n./main number" << endl;
            return 0;
        }
        else
        {
            cout << "checking test : ";
            for (int i = 1; i <= 1000; i++)
            {
                cout << i << " ";
                OUTPUT.open(folder_output + to_string(i) + ".txt");
                run_bellman(to_string(i));
                OUTPUT.close();
            }
        }
    }
    else if (argc == 3 && isNumber(argv[1]) && isNumber(argv[2]))
    {
        cout << "checking test : ";
        START = stoi(argv[1]);
        END = stoi(argv[2]);
        for (int i = stoi(argv[1]); i <= stoi(argv[2]); i++)
        {
            cout << i << " ";
            OUTPUT.open(folder_output + to_string(i) + ".txt");
            run_bellman(to_string(i));
            OUTPUT.close();
        }
    }
    else
    {
        cout << "Please re-enter the correct command" << endl;
        cout << "./main task1\n./main task2\n./main task3OUTPUT\n./main number" << endl;
        return 0;
    }

    cout << "\nOK: without errors\n"
         << endl;
    comparefile(START, END);
    return 1;
}

bool isNumber(string str)
{
    for (int i = 0; i < str.length(); i++)
    {
        if (!isdigit(str[i]))
            return false;
    }
    return true;
}

void comparefile(int start, int end)
{
    vector<int> result;
    for (int i = start; i <= end; i++)
    {
        ifstream read_output(folder_output + to_string(i) + ".txt");
        ifstream read_expect(folder_expect + to_string(i) + ".txt");
        if (read_output.fail() || read_expect.fail())
        {
            cout << "Error reading file" << end;
            return;
        }
        string s1, s2;
        while (read_output >> s1 && read_expect >> s2)
        {
            if (s1 != s2)
            {
                result.push_back(i);
                break;
            }
        }
        if (read_output >> s1 || read_expect >> s2)
        {
            if (result.size() == 0 || result.size() > 0 && result[result.size() - 1] != i)
                result.push_back(i);
        }
    }

    if (result.size() == 0)
    {
        cout << "Success: test " << start << " to " << end << endl;
    }
    else
    {
        cout << "percent success : " << (1 - result.size() * 1.0 / (end - start + 1)) * 100 << "%" << endl;
        cout << "Fail : test [";
        for (int i = 0; i < result.size() - 1; i++)
        {
            cout << result[i] << ", ";
        }
        cout << result[result.size() - 1] << "]\n";
        cout << "link check comparefile: https://www.diffchecker.com/text-compare/" << endl;
    }
}